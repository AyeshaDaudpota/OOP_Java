class Main{
	public static void main(String[] args){
        // 1st Task Animal
        /*Dog d = new Dog();
        d.makeSound();*/


        // 2nd Task Person
		/*GraduateStudent s = new GraduateStudent("Ayesha",20,"AY101","Artificial Intelligence");
		s.displayInfo();*/


		//3rd Task Vehicle
		/*Car v = new Car("Tesla",72, 4);
		v.showDetails();
		Bike b = new Bike("Honda",50, " blacktype");
		b.showDetails();*/


       // 4th Task Shape
		Shape shape;
		shape  = new Circle();
		shape.draw();
        shape  = new Rectangle();
        shape.draw();


	}
}