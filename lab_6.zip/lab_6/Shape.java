class Shape{
	
	void draw(){
		System.out.print("Drawing a Shape");
	}
}