import java.util.Scanner;
class Task2{

public static void main(String[] args){
 Scanner input = new Scanner (System.in);

int nums[] = new int [10];
int sum = 0;
for (int i=0; i<nums.length; i++){
nums[i] = input.nextInt();
if (nums[i]%4==0){
sum +=nums[i];
}
}
System.out.println("-------------------------------");
System.out.println(sum);
}
}