import java.util.Scanner;

class Task5{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		int Array1[][] = new int[4][5];
		int Array2[][] = new int[4][5];
		
		System.out.println("Enter the Matrix");
		for (int i= 0 ; i<4 ; i++)
		{
			for (int j= 0 ; j< 5 ; j++)
			{
				Array1[i][j] = input.nextInt();
			}
			System.out.println("----------");
		}
		for (int i= 0 ; i< 4 ; i++)
		{
			for (int j= 0 ; j< 5 ; j++)
			{
					System.out.print(Array1[i][j] + "  ");
			}
			System.out.println();
		}
}
}
