import java.util.Scanner;
class Task6{

public static void main(String[] args){
Scanner user_input = new Scanner (System.in);
System.out.println("Enter your age");
int Age = user_input.nextInt();
String result =(Age>=18)? " You are ELigible for voting." : "You are under age.";
System.out.print(result);

}

}