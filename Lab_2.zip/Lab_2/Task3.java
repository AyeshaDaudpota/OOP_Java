import java.util.Scanner;
class Task3{

public static void main(String[] args){
Scanner input = new Scanner (System.in);
System.out.print("Enter number of rows of Matrix : ");
int row = input.nextInt();

System.out.print("Enter number of columns of Matrix : ");
int col = input.nextInt();

int Array1[][] = new int[row][col];
int Array2[][] = new int[row][col];
System.out.println("Enter input for Matrix1 : ");
for (int i=0; i<row; i++){
for(int j=0; j<col; j++){
   Array1[i][j] = input.nextInt();
}
}
System.out.println("Enter input for Matrix2 : ");
for (int i=0; i<row; i++){
for(int j=0; j<col; j++){
   Array2[i][j] = input.nextInt();
}
}
System.out.println("Sum : ");
for (int i=0; i<row; i++){
for(int j=0; j<col; j++){
   System.out.print( Array1[i][j]+  Array2[i][j] + "\t");
}
System.out.println();
}
System.out.println();

}

}