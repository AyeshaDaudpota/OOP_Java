import java.util.Scanner;
public class Task7{
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        int array[] = {4,36,57,17,64,39,55,57};
        int max = array[0];
         int min = array[0];
        for (int i = 0 ; i<array.length ; i++){
            if (max<= array[i]){
                max = array[i];
            }
            else if(min>= array[i]){
                min = array[i];
            }
        }
        System.out.println("Maximum Number: " + max);
        System.out.println("Minimum Number : " + min);
        if (max %2==0){
            System.out.println("Maximum number is Divisible by 2 "+ max );
        }
        else{
            System.out.println("Maximum number is not Divisible by 2 "+ max);
        }
    }
}
