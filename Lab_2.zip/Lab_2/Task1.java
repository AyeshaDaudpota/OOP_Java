import java.util.Scanner;
class Task1{

public static void main(String[] args){
Scanner input = new Scanner (System.in); 
   
char[] consonant = {'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};
System.out.print("Enter the character : ");
char user_input = input.next().charAt(0);

boolean isConst = false;

for (int i=0; i<consonant.length; i++){
if(user_input == consonant[i]){
isConst = true;
break;}
}

if (isConst){
System.out.println(user_input + " is Consonant");}

else{

System.out.println(user_input + " is Not-Consonant");
}
}}