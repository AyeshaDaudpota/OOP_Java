import java.util.Scanner;
class Task4{

public static void main(String[] args){
 Scanner user_input = new Scanner(System.in);
String[] names = new String[6];

System.out.println("Enter the names");

for (int i=0; i<names.length; i++){
   names[i] = user_input.nextLine();
}

boolean isPresent = false;
for (String name : names){

if (name.equalsIgnoreCase("Ali")){
  isPresent = true;
  break;
}
}

if (isPresent)
{
System.out.print("Name ALi Is Found");

}
else{
System.out.print("Name ALi Not Found");
}
}
}