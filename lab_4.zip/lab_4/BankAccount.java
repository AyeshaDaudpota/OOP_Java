class BankAccount{
int balance;
int accountnumber;
BankAccount(int balance, int accountnumber){
this.balance=balance;
this.accountnumber=accountnumber;
}
public void checkBal(){
System.out.println(" Check Balance :" + balance);
}
public void deposit(int amount){
balance += amount;
System.out.println(" Deposited Balance is :" + balance);
}
public void withdraw(int amount){
if (amount <= balance){
balance -= amount;
System.out.println(" Balance after withdrawn :" + balance);
}else{
System.out.println("Insufficient Balance");
}
}
public static void main(String[] args){
BankAccount acc1 = new BankAccount(1000, 1);
BankAccount acc2 = new BankAccount(500, 2);
acc1.checkBal();
acc2.checkBal();

acc1.deposit(500);
acc1.checkBal();
acc2.deposit(1500);
acc2.checkBal();
acc2.withdraw(200);
acc2.checkBal();
}
}