class ICIC extends Bank{

	double getInterestRate(){
		return 8.2;
	}
}