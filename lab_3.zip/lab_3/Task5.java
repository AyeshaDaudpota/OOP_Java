import java.util.Scanner;
class Task5{
public static void main(String[] args){
Scanner input = new Scanner(System.in);
boolean exit = true;
boolean[][] isSeats = {{false,false},{true,true},{false,true},{true,false}};
do{
System.out.println("Press 1 to see available seats");
System.out.println("Press 2 to see reserve seats");
System.out.println("Press 3 for Exit");
char userinput = input.next().charAt(0);
switch (userinput){
case '1' :
System.out.println("\t\t Available Seats");
System.out.println("Seats which are true they are available");
System.out.println("Seats which are false they are reserved");
for(int row=0; row<4; row++){
  for(int col=0; col<2; col++){
   System.out.print(row+","+col+"."+isSeats[row][col]+"\t");
   }System.out.println();
    System.out.println();
}
break;
case '2' :
System.out.println("\t\tReserve your Seat");
System.out.println("Enter the Row : ");
int userrow = input.nextInt();
System.out.println("Enter the Column : ");
int usercol = input.nextInt();
if(userrow>3){
System.out.println("Invalid row input!");
if (usercol>1){
System.out.println("Invalid column input!");
continue;
}
else{
if(isSeats[userrow][usercol]){
System.out.println("This not reseved do you want to reserve this then press '1' " );
int reserving = input.nextInt();
if (reserving==1){
isSeats[userrow][usercol]=false;
System.out.println("Thankyou for reserving Seat " +userrow+" , "+usercol);
}
}
else{
System.out.println("Sorry! this seat is Reserved:(" );
}
}
}
break;
case '3' :
System.out.println("Thank you! ");
exit=false;
default:
System.out.println("Invalid Input.. Enter number in Range 1 to 3");
}
}while(exit);

}//main
}//end