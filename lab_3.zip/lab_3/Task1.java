import java.util.Scanner;
class Task1{

public static void main(String[] args){
Scanner user_input = new Scanner(System.in);

System.out.println("Enter the range of the numbers");
System.out.print("Enter the Starting Point : ");
int Start = user_input.nextInt();

System.out.print("Enter the ending point : ");
int End = user_input.nextInt();


for (int num = Start; num<=End; num++){
boolean isPrime = true;
    for (int j=2; j<num; j++){
if (num%j==0){

isPrime = false;
break;
}
   
}

if (isPrime){
System.out.println(num);
}

}

}

}