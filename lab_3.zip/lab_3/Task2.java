import java.util.Scanner;
class Task2{
public static void main(String[] args){
Scanner user_input = new Scanner(System.in);
System.out.println("Enter the text");
String text = user_input.nextLine();
String rev = "";
System.out.println(text);
for (int i= text.length()-1; i>=0; i--){
rev = rev+text.charAt(i);
}
if (text.equals(rev)){
System.out.print("Palindrome");
}
else{
System.out.print("Not Palindrome");
}
}

}