class Task3{
public static void main(String[] args){
int sum_of_even = 0;
int array[][] = {{12,13,15,16,},{11,110,121,17},{17,18,100,21}};
for (int i=0; i<3; i++){
    for (int j=0; j<4; j++){

      if (array[i][j]%2==0){
    array[i][j] = array[i][j]/2;
          }
System.out.print(array[i][j]+ "\t");
       }
System.out.println("");
     }
for (int i=0; i<3; i++){
    for (int j=0; j<4; j++){
       if (array[i][j]%2!=0){
System.out.println("Odd Numbers" + array[i][j] +"  ");
             }
         }
     }
for (int i=0; i<3; i++){
    for (int j=0; j<4; j++){
 if (array[i][j]%2==0){
sum_of_even= sum_of_even+array[i][j];
          }
        }
     }

System.out.println("Sum of even divided by 2: "+sum_of_even);
}

}


