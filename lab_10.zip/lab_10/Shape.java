abstract class Shape{

	abstract public double area();

}