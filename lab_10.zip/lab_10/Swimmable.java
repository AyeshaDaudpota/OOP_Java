interface Swimmable{

	public void swim();
	
}