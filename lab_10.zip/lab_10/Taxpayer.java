interface Taxpayer{
	
	public double payTax();
}