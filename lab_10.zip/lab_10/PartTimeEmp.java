class PartTimeEmp extends Employee implements Taxpayer{
	double salary;
	double hour;

   PartTimeEmp(String name, String id, double salary, double hour){
      super(name,id);
      this.salary=salary;
      this.hour=hour;

   }
   public double calculateSalary(){
      return salary*hour;
   }

   public double payTax(){
      return calculateSalary()*0.1;

   }
   void display(){
   	System.out.println("Name of Employee: "+name);
   	System.out.println("Id of Employee: "+id);
   	System.out.println("Salary of Part-Time-Employee per hour: "+ salary);
   }

}