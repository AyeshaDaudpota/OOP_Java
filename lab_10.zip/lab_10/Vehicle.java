interface Vehicle{

	public void start();

	public void stop();
}