class Main{
	public static void main(String[] args){
         // task 1
		// Dog d = new Dog();
		// d.eat();
		// d.makeSound();
		// Cat c = new Cat();
		// c.makeSound();
		

		// task 2
		// Car c = new Car();
		// c.start();
		// c.stop();
		// Bike b = new Bike();
		// b.start();
		// b.stop();

        // task 3
		// Rectangle r = new Rectangle(12,4);
		// System.out.println(r.area());
		// r.print();

		//task 4
		// Duck d = new Duck();
		// d.fly();
		// d.swim();
         
         //task 5
		FullTimeEmp f = new FullTimeEmp("Ayesha","A82",100000);
		f.display();
		f.calculateSalary();
		System.out.println("Tax: "+f.payTax());

		PartTimeEmp p = new PartTimeEmp("Aqsa","A83",2000,750);
		p.display();
		System.out.println("Total Salary: "+p.calculateSalary());
		System.out.println("Tax: "+p.payTax());



	}
}