interface Flyable{
	
	public void fly();


}