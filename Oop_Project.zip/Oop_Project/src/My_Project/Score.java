package My_Project;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Score extends JFrame implements ActionListener{
    JButton Quit;
    
   // public static int score = 0;
    Score(String name, int score){
       // this.score = score;
        
        setBounds(300,70,750,550);
        getContentPane().setBackground(new Color(240,255,255));
        setLayout(null);
        
     ImageIcon il = new ImageIcon(ClassLoader.getSystemResource("Icons/sc2.jpg"));
     Image i2 = il.getImage().getScaledInstance(400,350,Image.SCALE_DEFAULT);
     ImageIcon i3 = new ImageIcon(i2);
     JLabel image = new JLabel(i3);
     image.setBounds(0, 150, 300, 250);
     add(image);
     
     JLabel heading = new JLabel("Thank you " + name + " for Playing Creative Minds");
     heading.setBounds(45,30,700,30);
     heading.setFont(new Font("Sens-serif", Font.BOLD, 26));
     add(heading);
     
     JLabel lblscore = new JLabel("Your score is "+ score);
     lblscore.setBounds(400,200,300,30);
     lblscore.setFont(new Font("MV Boli", Font.BOLD, 22));
     add(lblscore);
     
     JButton submit = new JButton("Play Again ");
        submit.setBounds(400,270,120,40);
        submit.setBackground(new Color(0, 0 , 139));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        add(submit);
     
        Quit = new JButton("Quit");
        Quit.setBounds(400,350,120,40);
        Quit.setBackground(new Color(0, 0 , 139));
        Quit.setForeground(Color.WHITE);
        Quit.addActionListener(this);
        add(Quit);
     
     setVisible(true);
      
    }
    
    public void actionPerformed(ActionEvent ae){
        
        if(ae.getSource()== Quit){
            setVisible(false);
          System.exit(0);
        }
        else{
        setVisible(false);
        new Login(); 
        }
    }
    
    public static void main(String[] args){
        new Score("",0);
    }
    
}
