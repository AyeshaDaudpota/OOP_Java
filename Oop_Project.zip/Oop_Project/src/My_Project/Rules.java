  
package My_Project;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Rules extends JFrame implements ActionListener {
    
    String name; 
    JButton Back , start, mcq;
    
    Rules(String name){
        this.name=name;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
     JLabel heading = new JLabel("Welcome "+ name+ " to Creative Minds");
     heading.setBounds(125,30, 700 , 30);
     heading.setFont(new Font("Sens-serif", Font.CENTER_BASELINE, 28));
     heading.setForeground(new Color(0, 0 , 139));
     add(heading);
     
     JTextArea rules = new JTextArea();
     rules.setBounds(20, 90,600,350);
     rules.setFont(new Font("Tahoma", Font.PLAIN, 18));
     rules.setText(
   
             "1. Register your name before starting the quiz.\n\n" +
             "2. Each question has one correct answer.\n\n"+
             "3. Complete the quiz within the given time limit.\n\n"+
             "4. You cannot change answers after submission.\n\n"+
             "5. Each correct answer award points, no negative marking.\n\n"+      
             "6. The quiz auto submits when time runs out.\n\n"+
             "7. Do not use external help and cheat in exams.\n\n"+
             "8. Final scored are calculated after submission.\n\n>"
            
     );
     rules.setEditable(false);
     rules.setLineWrap(true);
     rules.setForeground(new Color(0, 0 , 139));
     add(rules);
     
     mcq = new JButton("Add MCQ's");
     mcq.setBounds(150,500,100,30);
     mcq.setFocusable(false);
     mcq.setBackground(new Color(240, 230, 140 ));
     mcq.setForeground(new Color(0, 8 , 139));
     mcq.addActionListener(this);
     add(mcq);
     
     Back = new JButton("Back");
     Back.setBounds(300,500,100,30);
     Back.setFocusable(false);
     Back.setBackground(new Color(240, 230, 140 ));
     Back.setForeground(new Color(0, 8 , 139));
     Back.addActionListener(this);
     add(Back);
     
     start = new JButton("Start");
     start.setBounds(450,500,100,30);
     start.setFocusable(false);
     start.setBackground(new Color(240, 230, 140 ));
     start.setForeground(new Color(0, 8 , 139));
     start.addActionListener(this);
     add(start);
     
       setSize(800, 650);
       setLocation(300, 20);
       setVisible(true);
    }
     public void actionPerformed(ActionEvent ae){
      if(ae.getSource()== start){
          setVisible(false);
          new Quiz(name);
      }
      else if(ae.getSource()==mcq){
        setVisible(false);
        new AddMcqs(name);
      }
      else{
       setVisible(false);
       new Login(); 
      }
     
     }
             
    
   
    
    public static void main(String[] args){
        
        
        new Rules("Ayesha");
    }
    
}
