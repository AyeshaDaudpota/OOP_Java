
package My_Project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;



public class AddMcqs extends JFrame implements ActionListener {
    
     JLabel heading, tag, tag1, tag2, tag3, tag4 ;
     JTextField q1, op1, op2, op3, op4;
     JButton save, back;
     String name;
     String question, opt1, opt2, opt3, opt4;

    AddMcqs(String name){
        this.name = name;
         setBounds(300,70,750,550);
        getContentPane().setBackground(new Color(240,255,255));
        setLayout(null);
        
     heading = new JLabel("Add MCQ's");
     heading.setBounds(280,60, 300 , 45);
     heading.setFont(new Font("Sens-serif", Font.CENTER_BASELINE, 40));
     heading.setForeground(new Color(0, 0 , 139));
     add(heading);
     
     tag = new JLabel("Que:");
     tag.setBounds(20,150, 300 , 30);
     tag.setFont(new Font("Tahoma", Font.CENTER_BASELINE, 20));
     tag.setForeground(new Color(0, 0 , 139));
     add(tag);
     
     q1 = new JTextField("");
     q1.setBounds(80,150, 300 , 40);
     q1.setSize(500,40);
     q1.setFont(new Font("Tahoma", Font.PLAIN, 16));
     q1.setForeground(new Color(0, 0 , 0));
     add(q1);
     
     tag1 = new JLabel("Opt1:");
     tag1.setBounds(20,210, 300 , 30);
     tag1.setFont(new Font("Tahoma", Font.CENTER_BASELINE, 20));
     tag1.setForeground(new Color(0, 0 , 139));
     add(tag1);
     
     op1 = new JTextField("");
     op1.setBounds(80,210, 300 , 40);
     op1.setSize(350,40);
     op1.setFont(new Font("Tahoma", Font.PLAIN, 16));
     op1.setForeground(new Color(0, 0 , 0));
     add(op1);
     
     tag2 = new JLabel("Opt2:");
     tag2.setBounds(20,270, 300 , 30);
     tag2.setFont(new Font("Tahoma", Font.CENTER_BASELINE, 20));
     tag2.setForeground(new Color(0, 0 , 139));
     add(tag2);
     
     op2 = new JTextField("");
     op2.setBounds(80,270, 300 , 40);
     op2.setSize(350,40);
     op2.setFont(new Font("Tahoma", Font.PLAIN, 16));
     op2.setForeground(new Color(0, 0 , 0));
     add(op2);
     
     tag3 = new JLabel("Opt3:");
     tag3.setBounds(20,330, 300 , 30);
     tag3.setFont(new Font("Tahoma", Font.CENTER_BASELINE, 20));
     tag3.setForeground(new Color(0, 0 , 139));
     add(tag3);
     
     op3 = new JTextField("");
     op3.setBounds(80,330, 300 , 40);
     op3.setSize(350,40);
     op3.setFont(new Font("Tahoma", Font.PLAIN, 16));
     op3.setForeground(new Color(0, 0 , 0));
     add(op3);
     
     tag4 = new JLabel("Opt4:");
     tag4.setBounds(20,390, 300 , 30);
     tag4.setFont(new Font("Tahoma", Font.CENTER_BASELINE, 20));
     tag4.setForeground(new Color(0, 0 , 139));
     add(tag4);
     
     op4 = new JTextField("");
     op4.setBounds(80,390, 300 , 40);
     op4.setSize(350,40);
     op4.setFont(new Font("Tahoma", Font.PLAIN, 16));
     op4.setForeground(new Color(0, 0 , 0));
     add(op4);
     
      back = new JButton("back");
      back.setBounds(250,500,120,40);
      back.setBackground(new Color(0, 0 , 139));
      back.setFocusable(false);
      back.setForeground(Color.WHITE);
      back.addActionListener(this);
      add(back);
     
      save = new JButton("Save in file");
      save.setBounds(450,500,120,40);
      save.setBackground(new Color(0, 0 , 139));
      save.setFocusable(false);
      save.setForeground(Color.WHITE);
      save.addActionListener(this);
      add(save);
     
     setSize(800, 650);
     setLocation(300, 20);
     setVisible(true);
    
    
    }
     @Override
   public void actionPerformed(ActionEvent ae){
   if(ae.getSource() == back ){
      setVisible(false);
      new Rules(name);
   }
   else if(ae.getSource() == save){
      saveMCQToFile();
      clearField();
   }
   }
   private void saveMCQToFile() {
        question = q1.getText();
         opt1 = op1.getText();
         opt2 = op2.getText();
         opt3 = op3.getText();
         opt4 = op4.getText();
         
         try (FileWriter writer = new FileWriter("mcqs.txt",true)) {
            writer.write("Q: " + question + "\n");
            writer.write("1) " + opt1 + "\n");
            writer.write("2) " + opt2 + "\n");
            writer.write("3) " + opt3 + "\n");
            writer.write("4) " + opt4 + "\n");
            writer.write("----------------------\n");
            JOptionPane.showMessageDialog(null, "Saved successfully" , "Message" , JOptionPane.INFORMATION_MESSAGE);
            
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error saving MCQ: " + ex.getMessage());
        }
   }
   private void clearField(){
         q1.setText("");
         op1.setText("");
         op2.setText("");
         op3.setText("");
         op4.setText("");
   
   }
   
   
    public static void main(String[] args){
        new AddMcqs("");
    }
   
}
