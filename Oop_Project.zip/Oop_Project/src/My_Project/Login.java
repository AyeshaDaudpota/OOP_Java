
package My_Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
public class Login extends JFrame implements ActionListener{
    
    JButton rules, Back;
    JTextField tfname;
    
    Login(){
     getContentPane().setBackground(Color.WHITE);
     setLayout(null);
     
     
     
     ImageIcon il = new ImageIcon(ClassLoader.getSystemResource("Icons/Quiztime.jpg"));
     setIconImage(il.getImage());
     JLabel image = new JLabel(il);
     image.setBounds(0, 0, 600, 500);
     image.setLocation(05, 05);
     add(image);
     
     JLabel heading = new JLabel("Creative Minds");
     heading.setBounds(750,60, 300 , 45);
     heading.setFont(new Font("Sens-serif", Font.CENTER_BASELINE, 40));
     heading.setForeground(new Color(0, 0 , 139));
     add(heading);
     
     JLabel name = new JLabel("Enter your name");
     name.setBounds(810,150, 300 , 20);
     name.setFont(new Font("Mongolian Baiti", Font.BOLD, 20));
     name.setForeground(new Color(0, 0 , 139));
     add(name);
     
     tfname = new JTextField();
     tfname.setBounds(735, 200,300,30);
     tfname.setFont(new Font("Sens serif", Font.BOLD, 20));
     tfname.setForeground(new Color(0, 8 , 139));
     add(tfname);
     
     rules = new JButton("Rules");
     rules.setBounds(735,270,120,30);
     rules.setBackground(new Color(240, 230, 140 ));
     rules.setForeground(new Color(0, 8 , 139));
     rules.addActionListener(this);
     add(rules);
     
     Back = new JButton("Back");
     Back.setBounds(915,270,120,30);
     Back.setBackground(new Color(240, 230, 140 ));
     Back.setForeground(new Color(0, 8 , 139));
     Back.addActionListener(this);
     add(Back);
     
     setSize(1200,550);
     setVisible(true); // to show
     setLocation(50,100); // generate 
     }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == rules){
           String name = tfname.getText();
            
          setVisible(false);
          new Rules(name); 
          
    }
    else if(ae.getSource() == Back){
        setVisible(false);
    }
    }
    
    public static void main(String[] args){
     new Login(); 
    
    }
    
}
