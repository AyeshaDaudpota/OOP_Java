import java.util.Scanner;
class task1{
	public static void main(String[] args){
	Scanner input = new Scanner(System.in);
     System.out.print("Enter the String: ");
     String check = input.nextLine();
     if (check.isEmpty()){
     	System.out.println("String is Empty");
     	}
     	else{
     		System.out.println("String is not Empty");
     	}
     }
	}


