class employee{
String name;
String empID;
int salary;

employee(String name, String empID, int salary){
this.name=name;
this.empID=empID;
this.salary=salary;
}
void displaydetails(){
System.out.println("Name of Employee: "+ name);
System.out.println( "ID " + empID);
System.out.println("Employee Salary: "+ salary);
}
void incSalary(int amount){
salary += amount;
System.out.println("Increased Salary: "+ salary);
}
int annualSalary(){
System.out.println("Annual Salary: "+ salary*12);
return salary;
}

public static void main(String[] args){

employee e1 = new employee("Ayesha","A0082",50000);

e1.displaydetails();
e1.incSalary(2000);
e1.annualSalary();
}
}